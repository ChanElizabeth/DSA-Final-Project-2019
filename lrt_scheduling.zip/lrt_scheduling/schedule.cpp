#include <iostream>
#include <string>
#include "schedule.hpp"
using namespace std;

//constructor
Schedule::Schedule(string filename, string filename2)
{
	this -> filename = filename;
	ifstream ifs;
	ifs.open(filename);
	if (ifs.fail())
	{
		cout << filename << " not found. creating new one." << endl;
		ofstream ofs;
        ofs.open(filename);
		ofs.close();
	}
	while (!ifs.eof())
	{
		string date, departure;
		int carriage, capacity;
        int trainId;
        ifs >> trainId >> date >> departure >> carriage >> capacity;
        if (date != "")
        {
            Train t(trainId, carriage, capacity, departure, date);
            trains.push_back(t);
        }
        else break;
	}
    
    this -> filename2 = filename2;
    ifstream ifs2;
    ifs2.open(filename2);
    if (ifs2.fail())
    {
        cout << filename2 << " not found. creating new one." << endl;
        ofstream ofs2;
        ofs2.open(filename2);
        ofs2.close();
    }
    while (!ifs2.eof())
    {
        string name, date, departure;
        int id, trainId, carriageId;
        ifs2 >> id >> name >> date >> departure >> trainId >> carriageId;
        if (name != "")
        {
            Passenger p(name, id, departure, date, trainId, carriageId);
            passengers.push_back(p);
            for (int i = 0; i < trains.size(); i++)
            {
                if (trains[i].getTrainid() == trainId)
                {
                    trains[i].addPassenger(carriageId, p);
                    break;
                }
            }
        }
        else break;
    }
    
    for(int i = 0; i < trains.size(); i++){
        trainId = trains[i].getTrainid();
    }
    cout << "size " << trains.size() << endl;
    
    for(int i = 0; i < passengers.size(); i++){
        passengerId = passengers[i].getId();
    }
    cout << "size " << passengers.size() << endl;
	// https://stackoverflow.com/questions/20707257/use-ifstream-to-read-multiple-lines
}

//destructor
Schedule::~Schedule()
{
    ofstream outFile;
    outFile.open("schedule.txt");

    if (outFile.fail())
    {
        cerr << "Error opening file" <<endl;
        exit(1);
    }
    
    string toSave = "";
    for (int i = 0; i < trains.size(); ++i)
    {
        Train t = trains[i];
        toSave += to_string(t.getTrainid()) + " " + t.getDate() + " " + t.getPlace() + " " + to_string(t.getNumOfCarriage()) + " " + to_string(t.getCarriage(0).getCapacity()) + "\n";
    }
    
    if(outFile.is_open())
    {
        outFile << toSave;
        outFile.close();
    }
    else
    {
        cout<< "File is not opened" <<endl;
    }
    
    ofstream outFile2;
    outFile2.open("passenger.txt");
    
    if (outFile2.fail())
    {
        cerr << "Error opening file" <<endl;
        exit(1);
    }
    
    string toSave2 = "";
    for (int i = 0; i < passengers.size(); i++)
    {
        Passenger p = passengers[i];
        toSave2 += to_string(p.getId()) + " " + p.getName() + " " + p.getDate() + " " + p.getDep() + " " + to_string(p.getTrainid()) + " " + to_string(p.getCarriageid()) +  "\n";
    }
    
    if(outFile2.is_open())
    {
        outFile2 << toSave2;
        outFile2.close();
    }
    else
    {
        cout<< "File is not opened" <<endl;
    }
}

//add lrt schedule
void Schedule::addSchedule(int numOfCarriage, int carriageCapacity, string departurePlace, string departureDate)
{
    ++trainId;
	trains.push_back(Train(trainId, numOfCarriage, carriageCapacity, departurePlace, departureDate));
}

//get the schedule
vector <Train> Schedule::getTrains()
{
	return trains;
}

//get the passengers
vector <Passenger> Schedule::getPassengers()
{
    return passengers;
}

//function to view schedule
void Schedule::viewSchedule(){
    for (int i = 0; i < trains.size(); i++) {
        cout << "Trains " << i << "; " << "Departure Place: " << trains[i].getPlace() << ", Number of Carriage: " << trains[i].getNumOfCarriage() << ", Available Capacity: " << trains[i].getCapacity() << ", Departure Date: " << trains[i].getDate() << endl;
    }
}

//fumction to remove schedule
void Schedule::removeSchedule(int id)
{
    if(id > trains.size() || id < 0)
    {
        trains.erase(trains.begin() + id);
        trains[id].setTrainid(id);
        cout << "Delete successfully" <<endl;
    }
    else cout << "Invalid input" <<endl;
}

void Schedule::savePassenger(string name, string departure, string date , int trainId , int carriage)
{
    ++passengerId;
    passengers.push_back(Passenger(name, passengerId, departure, date, trainId, carriage));
}

void Schedule::addPassenger(int train, int carriage, string name, string departure, string date , int trainId , int carriagechoose)
{
    Passenger newpass( name, passengerId,  departure,  date ,  trainId ,  carriagechoose);
    trains[train].addPassenger(carriage, newpass);
}

