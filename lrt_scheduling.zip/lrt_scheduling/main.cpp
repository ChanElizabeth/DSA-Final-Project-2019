//https://stackoverflow.com/questions/3396378/change-the-working-directory-in-xcode
#include <iostream>
#include <vector>
#include <string>
#include <time.h>

#include "passenger.hpp"
#include "schedule.hpp"
#include "train.hpp"

using namespace std;

void checkSeatAvailability();
void bookTicket();
void checkSchedule();
void checkBooking();
bool isDate(string d);

Schedule schedule("schedule.txt", "passenger.txt");

//admin function
int admin()
{
    int option;
    string input;
    string p;
    int numOfCarriage = 0, carriageCapacity = 0;
    string departurePlace, departureDate;
    cout <<"Enter password: "<< endl;
    cin >> p;
   
    while (true) {
        if (p != "hello"){
            cout<<"Incorrect Password"<<endl;
            break;
        }
        else{
            cout <<"================================="<< endl;
            cout <<"     JAKARTA LRT OPERATION"<<endl;
            cout <<"================================="<< endl;
            cout <<" 1. Add schedule \n 2. Delete schedule \n 3. View schedule \n 0. back to main" <<endl;
            cin >> option;
            switch (option) {
                case 0:
                    return 0;
                    break;
                case 1:
                    cout <<"Number of carriage: "<< endl;
                    cin >> numOfCarriage;
                    cout <<"Carriage Capacity: "<< endl;
                    cin >> carriageCapacity;
                    cout <<"Depature Place: "<< endl;
                    cin >> departurePlace;
                    do{
                        cout <<"Departure Date: (dd/mm/yyyy) "<< endl;
                        cin >> departureDate;
                    } while(!isDate(departureDate));
                    schedule.addSchedule(numOfCarriage, carriageCapacity, departurePlace, departureDate);
                    cout << "Add Successfully" <<endl;
                    break;
                case 2:
                    int choosenid;
                    schedule.viewSchedule();
                    cout << " Choose train to be deleted: (Enter Train ID) " <<endl;
                    cin >> choosenid;
                    schedule.removeSchedule(choosenid);
                    break;
                case 3:
                    schedule.viewSchedule();
                    break;
                default:
                    break;
            }
        }
    }
    return 0;
}

//user function
int user()
{
    int option;
    string input;
    char date[30];
    
    while(true)
    {
        time_t t = time(NULL);
        struct tm tm = *localtime(&t);
        sprintf(date, "%d-%d-%d %d:%d:%d", tm.tm_mday,tm.tm_mon + 1, tm.tm_year + 1900,tm.tm_hour, tm.tm_min, tm.tm_sec);
        cout <<endl<<"================================="<< endl;
        cout << date<< endl;
        
        cout <<"================================="<< endl;
        cout <<"          JAKARTA LRT"<<endl;
        cout <<"================================="<< endl;
        cout <<" 1. Book your ticket \n 2. Check LRT's seat availability \n 3. Check LRT schedule  \n 4. Check your Booking \n 0. back to main" << endl;
        cin >> option;
        
        switch (option)
        {
            case 0:
                return 0;
            case 1:
                bookTicket();
                break;
            case 2:
                checkSeatAvailability();
                break;
            case 3:
                checkSchedule();
                break;
            case 4:
                checkBooking();
                break;
            default:
                cout<<"Invalid input"<<endl;
        }
        
    }
}

//main function
int main(int argc, char** argv) {
    int option;
    string input;
    schedule.getTrains();
    while (true) {
        cout <<"================================="<< endl;
        cout <<"             WELCOME"<<endl;
        cout <<"================================="<< endl;
        cout << " 1. Admin \n 2. User \n 0. exit" << endl;
        cin >> option;
        
        switch (option) {
            case 0:
                exit(0);
            case 1:
                admin();
                break;
            case 2:
                user();
                break;
            default:
                break;
        }
    }
}

//check availabiliry of the seats
void checkSeatAvailability()
{
    cout <<"================================="<< endl;
    cout <<"         JAKARTA LRT"<<endl;
    cout <<"================================="<< endl;
    cout << "Available seats: "<<endl;
    vector<Train> trains = schedule.getTrains();
    for (int i = 0; i < trains.size(); i++)
    {
        cout<< i + 1 << " Train " << trains[i].getPlace() << ": " << trains[i].availableSpace() << "/" << trains[i].getCapacity()<<"  "<<trains[i].getDate()<<endl;
    }
}

//function to book the ticket
void bookTicket()
{
    int train, carriage;
    string name;
    cout <<"================================="<< endl;
    cout <<"         JAKARTA LRT"<<endl;
    cout <<"================================="<< endl;
    while(true)
    {
        cout <<"Choose train: "<<endl;
        vector<Train> trains = schedule.getTrains();
        for (int i = 0; i < trains.size(); i++)
        {
            cout<< i + 1 << " Train " << trains[i].getPlace() << ": " << trains[i].availableSpace() << "/" << trains[i].getCapacity()<<"  "<<trains[i].getDate()<<endl;
        }
        cout<<"Enter 0 to cancel your booking"<<endl;
        cin>>train;
        
        if (train == 0) return;
        
        if (train > trains.size() || train < 0)
        {
            cout<<"Invalid input"<<endl;
            continue;
        }
        
        train--;
        
        if (trains[train].availableSpace() <= 0)
        {
            cout << "The train you selected is full" << endl;
            continue;
        }
        
        break;
        
    }
    
    while(true)
    {
        cout<<"Choose carriage: "<<endl;
        vector<Train> trains = schedule.getTrains();
        for (int i = 0; i < trains[train].getNumOfCarriage(); i++)
        {
            cout<< "Carriage " << i + 1 << ": " << trains[train].getCarriage(i).getAvailable() << "/" << trains[train].getCarriage(i).getCapacity()<<endl;
        }
        
        cout<<"Enter 0 to cancel your booking"<<endl;
        cin>>carriage;
        
        if (carriage == 0) return;
        
        if (carriage > trains[train].getNumOfCarriage() || carriage < 0)
        {
            cout<<"Invalid input"<<endl;
            continue;
        }
        
        carriage--;
        
        if (trains[train].getCarriage(carriage).getAvailable() <= 0)
        {
            cout << "The carriage you selected is full" << endl;
            continue;
        }
        
        
        break;
    }
    
    cout<<"Enter your name: ";
    cin>>name;
    vector<Train> trains = schedule.getTrains();
    schedule.savePassenger(name, trains[train].getPlace(), trains[train].getDate(), trains[train].getTrainid(), carriage);
    schedule.addPassenger(train, carriage, name, trains[train].getPlace(), trains[train].getDate(), trains[train].getTrainid(), carriage);
    vector<Passenger> passengers = schedule.getPassengers();
    int bookId = 0;
    for (int i = 0; i < passengers.size(); i++){
        if (passengers[i].getName() == name){
            bookId = passengers[i].getId();
        }
    }
    cout << "Booking placed successfully. Your Booking Id is " << bookId << endl;
}

//check the lrt schedule available
void checkSchedule()
{
    vector<Train> trains = schedule.getTrains();
    cout << "------------------------------" <<endl;
    for (int i = 0; i < trains.size(); i++)
    {
        cout<< "Train " << i << "; \n" << "Departure Place: " << trains[i].getPlace() << "\nNumber of Carriage: " << trains[i].getNumOfCarriage() << "\nAvailable Capacity: " << trains[i].availableSpace() << "/" << trains[i].getCapacity()<< "\nDeparture Date: "<<trains[i].getDate() << "\n------------------------------" <<endl;
    }
}

//check the booking
void checkBooking()
{
    int id;
    cout << "Enter your Booking ID: " <<endl;
    cin >> id;
    vector<Passenger> passengers = schedule.getPassengers();
    cout << "------------------------------" <<endl;
    for (int i = 0; i < passengers.size(); i++)
    {
        if (passengers[i].getId() == id)
        {
            cout << "Your Booking:  \nID: " << passengers[i].getId() << "\nName: " << passengers[i].getName() << "\nTrain ID: " << passengers[i].getTrainid() << "\nCarriage No: " << passengers[i].getCarriageid() << "\nDeparture Place: " << passengers[i].getDep() << "\nDeparture Date: " << passengers[i].getDate() << "\n------------------------------" << endl;
        }
    }
}

//verify if the user input date or not
bool isDate(string d)
{
    if ( d[2] == '/' && (d[3] == '0' || d[3] == '1') && d[5] == '/' && d.length() == 10)
    {
        return true;
    }
    cout << "WRONG DATE FORMAT" <<endl;
    return false;
}
