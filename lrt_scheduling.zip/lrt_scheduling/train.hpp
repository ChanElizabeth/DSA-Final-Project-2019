#ifndef train_hpp
#define train_hpp
#include <stdio.h>
#include <vector>
#include "passenger.hpp"
#include "carriage.hpp"

#include <iostream>
using namespace std;

class Train
{
	private:
		vector <Carriage> carriages;
        int trainID;
		int numOfCarriage;
		string departurePlace;
		string departureDate;
	public:
		Train(int trainID, int numOfCarriage, int carriageCapacity, string departurePlace, string departureDate);
        void setTrainid(int id);
        int getTrainid();
		int getCapacity();
		int availableSpace();
		int getNumOfCarriage();
		Carriage getCarriage(int i);
		bool addPassenger(int carriageId, Passenger p);
		string getDate();
        string getPlace();
};

#endif
		
		


