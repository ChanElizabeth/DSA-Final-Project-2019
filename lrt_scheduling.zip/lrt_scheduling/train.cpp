#include "train.hpp"
#include <stdio.h>

#include <iostream>
using namespace std;

Train::Train(int trainID, int numOfCarriage, int carriageCapacity, string departurePlace, string departureDate)
{
    this -> trainID = trainID;
	this -> departurePlace = departurePlace;
	this -> numOfCarriage = numOfCarriage;
	this -> departureDate = departureDate;
	for (int i = 0; i < numOfCarriage; i++)
	{
		this -> carriages.push_back(Carriage(carriageCapacity));
	}
}

int Train::availableSpace()
{
	int total = 0;
	for (int i = 0; i < numOfCarriage; i++)
	{
		total += carriages[i].getAvailable();
	}
	return total;
}

void Train::setTrainid(int id){
    this -> trainID = id;
}

int Train::getTrainid()
{
    return trainID;
}

int Train::getCapacity()
{
	return numOfCarriage * carriages[0].getCapacity();
}

int Train::getNumOfCarriage()
{
	return numOfCarriage;
}

string Train::getDate()
{
	return departureDate;
}

string Train::getPlace()
{
    return departurePlace;
}

Carriage Train::getCarriage(int i)
{
	if(i > numOfCarriage && i < 0)
	{
		return Carriage(0);
	}
	return carriages[i];	
} 

bool Train::addPassenger(int carriageId, Passenger p)
{
	if (carriageId < 0 || carriageId > numOfCarriage) return false;
	if (carriages[carriageId].getAvailable() <= 0) return false;
	carriages[carriageId].addPassenger(p);
	return true;
}
