#ifndef passenger_hpp
#define passenger_hpp
#include <string>
#include <stdio.h>

#include <iostream>
#include <fstream>
#include <vector>
using namespace std;

class Passenger
{
	private:
		string name;
		int id;
		string departure;
		string date;
        int trainId;
        int carriageId;
        string filename;
	public:
		Passenger(string name, int id, string departure, string date, int trainId, int carriageId);
		string getName();
		int getId();
		string getDep();
		string getDate();
        int getTrainid();
        int getCarriageid();
};

#endif
