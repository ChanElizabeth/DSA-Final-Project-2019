#include <iostream>
#include "carriage.hpp"

using namespace std;

Carriage::Carriage(int capacity)
{
	this -> capacity = capacity;
	this -> occupied = 0;
}

int Carriage::getAvailable()
{
	return capacity - occupied;
}

int Carriage::getCapacity()
{
	return capacity;
}

void Carriage::addPassenger(Passenger p)
{
	if(getAvailable() > 0)
	{
		seats.push_back(p);
		occupied++;
	}
}
