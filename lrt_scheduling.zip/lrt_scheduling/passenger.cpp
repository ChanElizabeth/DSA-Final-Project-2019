#include "passenger.hpp"

Passenger::Passenger(string name, int id, string departure, string date, int trainId, int carriageId)
{
	this -> name = name;
	this -> id = id;
	this -> departure = departure;
	this -> date = date;
    this -> trainId = trainId;
    this -> carriageId = carriageId;
}

string Passenger::getName()
{
	return this -> name;
}

int Passenger::getId()
{
    return this -> id;
}

string Passenger::getDep()
{
    return this -> departure;
}

string Passenger::getDate()
{
    return this -> date;
}

int Passenger::getTrainid()
{
    return this -> trainId;
}

int Passenger::getCarriageid()
{
    return this -> carriageId;
}
