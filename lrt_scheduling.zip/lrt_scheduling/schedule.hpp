#ifndef schedule_hpp
#define schedule_hpp

#include <iostream>	
#include <fstream>
#include <vector>
#include "train.hpp"
#include "passenger.hpp"
using namespace std;

class Schedule
{
	private:
		vector <Train> trains;
        vector <Passenger> passengers;
		string filename;
        string filename2;
	public:
        int trainId;
        int passengerId;
		Schedule(string filename, string filename2);
		~Schedule();
		vector <Train> getTrains();
        vector <Passenger> getPassengers();
		void addSchedule(int numOfCarriage, int carriageCapacity, string departurePlace, string departureDate);
        void viewSchedule();
		void removeSchedule(int id);
        void addPassenger(int train, int carriage, string name, string departure, string date , int trainId , int carriagechoose);
        void savePassenger(string name, string departure, string date , int trainId , int carriage);
};

#endif
