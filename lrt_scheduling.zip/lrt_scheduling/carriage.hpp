#ifndef carriage_hpp
#define carriage_hpp

#include <iostream>
#include <vector>
#include "passenger.hpp"

using namespace std;

class Carriage
{
	private:
		vector <Passenger> seats;
		int capacity;
		int occupied;
		
	public:
		Carriage (int capacity);
		int getCapacity();
		int getAvailable();
		void addPassenger(Passenger p);
};

#endif
